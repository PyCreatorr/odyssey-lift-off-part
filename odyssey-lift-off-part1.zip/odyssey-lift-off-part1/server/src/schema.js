const { gql } = require ('apollo-server');

const typeDefs = gql`
type Query {
    "Query to get tracks"
    tracksForHome: [Track!]!
    "Fetch a specific track, provided a track's ID"
    track(id: ID!): Track
}

type Mutation {
    incrementTrackViews(id: ID!): IncrementTrackViewsResponse!
}

type IncrementTrackViewsResponse{
    "Similar to HTTP status code, represents the status of the mutation"
    code: Int!
    "Indicates whether the mutation wassuccessful"
    success: Boolean!
    message:String!
    "Updated track after asuccessful mutation"
    track: Track
}



"Some description"
type Track {
    id: ID!
    title: String!
    author: Author!
    thumbnail: String
    length: Int
    modulesCount: Int
    description: String
    numberOfViews: Int
    "The track's complete array of Modules"
    modules: [Module!]!
}

type Module {
    id: ID!
    title: String!
    length: Int
}

"Author of the track"
type Author {
    id: ID!
    name: String!
    photo: String
}
`;

module.exports = typeDefs;