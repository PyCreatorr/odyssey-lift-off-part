# Catstronauts - client

The starting point of the `client` code for Odyssey Lift-off I course.
