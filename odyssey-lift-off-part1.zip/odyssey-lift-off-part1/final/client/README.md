# Catstronauts - client

The final stage of the `client` code after completing the Odyssey Lift-off I course.
